FRUIT LEGENDS — MOBILE GAME BUILD
=================================

This is a playable, self-contained browser game build for Android phones and desktop browsers.

PLAY
1. Extract the ZIP.
2. Open index.html in a modern browser.
3. On a phone, use the on-screen arrows and ATTACK / POWER / DASH buttons.
4. Tap MENU for quests, the fruit shop, island travel, and saving.

FEATURES
- Four island environments with level-gated travel
- Mobile touch controls and PC keyboard controls
- Enemy encounters, attacks, fruit powers, dash movement
- Flame, Ice, Thunder and Nature fruits
- Beli currency, XP, levels, quest rewards
- Local progress saving in the browser on the same device

IMPORTANT
This ZIP is a playable HTML game build, not a compiled Android APK.
It does not install as a native Android application from this ZIP.
An APK requires an Android packaging/build step and testing on a device.
The game is an original adventure inspired by the broad genre of island
exploration games; it does not use Roblox or Blox Fruits assets.
